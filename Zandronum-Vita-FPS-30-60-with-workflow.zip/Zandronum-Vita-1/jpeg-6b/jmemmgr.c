/*
* jmemmgr.c
*
* Copyright (C) 1991-1997, Thomas G. Lane.
* This file is part of the Independent JPEG Group's software.
* For conditions of distribution and use, see the accompanying README file.
*
* This file contains the JPEG system-independent memory management
* routines.  This code is usable across a wide variety of machines; most
* of the system dependencies have been isolated in a separate file.
* The major functions provided here are:
*   * pool-based allocation and freeing of memory;
*   * policy decisions about how to divide available memory among the
*     virtual arrays;
*   * control logic for swapping virtual arrays between main memory and
*     backing storage.
* The separate system-dependent file provides the actual backing-storage
* access code, and it contains the policy decision about how much total
* main memory to use.
* This file is system-dependent in the sense that some of its functions
* are unnecessary in some systems.  For example, if there is enough virtual
* memory so that backing storage will never be used, much of the virtual
* array control logic could be removed.  (Of course, if you have that much
* memory then you shouldn't care about a little bit of unused code...)
*/

#define JPEG_INTERNALS
#define AM_MEMORY_MANAGER	/* we define jvirt_Xarray_control structs */
#include "jinclude.h"
#include "jpeglib.h"


/*
* Some important notes:
*   The allocation routines provided here must never return NULL.
*   They should exit to error_exit if unsuccessful.
*
*   It's not a good idea to try to merge the sarray and barray routines,
*   even though they are textually almost the same, because samples are
*   usually stored as bytes while coefficients are shorts or ints.  Thus,
*   in machines where byte pointers have a different representation from
*   word pointers, the resulting machine code could not be the same.
*/


/*
* Many machines require storage alignment: longs must start on 4-byte
* boundaries, doubles on 8-byte boundaries, etc.  On such machines, malloc()
* always returns pointers that are multiples of the worst-case alignment
* requirement, and we had better do so too.
* There isn't any really portable way to determine the worst-case alignment
* requirement.  This module assumes that the alignment requirement is
* multiples of sizeof(ALIGN_TYPE).
* By default, we define ALIGN_TYPE as double.  This is necessary on some
* workstations (where doubles really do need 8-byte alignment) and will work
* fine on nearly everything.  If your machine has lesser alignment needs,
* you can save a few bytes by making ALIGN_TYPE smaller.
* The only place I know of where this will NOT work is certain Macintosh
* 680x0 compilers that define double as a 10-byte IEEE extended float.
* Doing 10-byte alignment is counterproductive because longwords won't be
* aligned well.  Put "#define ALIGN_TYPE long" in jconfig.h if you have
* such a compiler.
*/

#ifndef ALIGN_TYPE		/* so can override from jconfig.h */
#define ALIGN_TYPE  double
#endif


/*
* We allocate objects from "pools", where each pool is gotten with a single
* request to jpeg_get_small() or jpeg_get_large().  There is no per-object
* overhead within a pool, except for alignment padding.  Each pool has a
* header with a link to the next pool of the same class.
* Small and large pool headers are identical except that the latter's
* link pointer must be FAR on 80x86 machines.
* Notice that the "real" header fields are union'ed with a dummy ALIGN_TYPE
* field.  This forces the compiler to make SIZEOF(small_pool_hdr) a multiple
* of the alignment requirement of ALIGN_TYPE.
*/

typedef union small_pool_struct * small_pool_ptr;

typedef union small_pool_struct {
	struct {
		small_pool_ptr next;	/* next in list of pools */
		size_t bytes_used;		/* how many bytes already used within pool */
		size_t bytes_left;		/* bytes still available in this pool */
	} hdr;
	ALIGN_TYPE dummy;		/* included in union to ensure alignment */
} small_pool_hdr;

typedef union large_pool_struct * large_pool_ptr;

typedef union large_pool_struct {
	struct {
		large_pool_ptr next;	/* next in list of pools */
		size_t bytes_used;		/* how many bytes already used within pool */
		size_t bytes_left;		/* bytes still available in this pool */
	} hdr;
	ALIGN_TYPE dummy;		/* included in union to ensure alignment */
} large_pool_hdr;


/*
* Here is the full definition of a memory manager object.
*/

typedef struct {
	struct jpeg_memory_mgr pub;	/* public fields */

	/* Each pool identifier (lifetime class) names a linked list of pools. */
	small_pool_ptr small_list[JPOOL_NUMPOOLS];
	large_pool_ptr large_list[JPOOL_NUMPOOLS];

	/* Since we only have one lifetime class of virtual arrays, only one
	* linked list is necessary (for each datatype).  Note that the virtual
	* array control blocks being linked together are actually stored somewhere
	* in the small-pool list.
	*/
	jvirt_barray_ptr virt_barray_list;

	/* alloc_sarray and alloc_barray set this value for use by virtual
	* array routines.
	*/
	JDIMENSION last_rowsperchunk;	/* from most recent alloc_sarray/barray */
} my_memory_mgr;

typedef my_memory_mgr * my_mem_ptr;


/*
* The control blocks for virtual arrays.
* Note that these blocks are allocated in the "small" pool area.
* System-dependent info for the associated backing store (if any) is hidden
* inside the backing_store_info struct.
*/

struct jvirt_barray_control {
	JBLOCKARRAY mem_buffer;	/* => the in-memory buffer */
	JDIMENSION rows_in_array;	/* total virtual array height */
	JDIMENSION blocksperrow;	/* width of array (and of memory buffer) */
	JDIMENSION maxaccess;		/* max rows accessed by access_virt_barray */
	JDIMENSION rows_in_mem;	/* height of memory buffer */
	JDIMENSION rowsperchunk;	/* allocation chunk size in mem_buffer */
	JDIMENSION cur_start_row;	/* first logical row # in the buffer */
	JDIMENSION first_undef_row;	/* row # of first uninitialized row */
	boolean pre_zero;		/* pre-zero mode requested? */
	boolean dirty;		/* do current buffer contents need written? */
	jvirt_barray_ptr next;	/* link to next virtual barray control block */
};


LOCAL(void)
out_of_memory (j_common_ptr cinfo, int which)
/* Report an out-of-memory error and stop execution */
{
	ERREXIT1(cinfo, JERR_OUT_OF_MEMORY, which);
}


/*
* Allocation of "small" objects.
*
* For these, we use pooled storage.  When a new pool must be created,
* we try to get enough space for the current request plus a "slop" factor,
* where the slop will be the amount of leftover space in the new pool.
* The speed vs. space tradeoff is largely determined by the slop values.
* A different slop value is provided for each pool class (lifetime),
* and we also distinguish the first pool of a class from later ones.
* NOTE: the values given work fairly well on both 16- and 32-bit-int
* machines, but may be too small if longs are 64 bits or more.
*/

static const size_t first_pool_slop[JPOOL_NUMPOOLS] = 
{
	1600,			/* first PERMANENT pool */
	16000			/* first IMAGE pool */
};

static const size_t extra_pool_slop[JPOOL_NUMPOOLS] = 
{
	0,			/* additional PERMANENT pools */
	5000			/* additional IMAGE pools */
};

#define MIN_SLOP  50		/* greater than 0 to avoid futile looping */


METHODDEF(void *)
alloc_small (j_common_ptr cinfo, int pool_id, size_t sizeofobject)
/* Allocate a "small" object */
{
	my_mem_ptr mem = (my_mem_ptr) cinfo->mem;
	small_pool_ptr hdr_ptr, prev_hdr_ptr;
	char * data_ptr;
	size_t odd_bytes, min_request, slop;

	/* Round up the requested size to a multiple of SIZEOF(ALIGN_TYPE) */
	odd_bytes = sizeofobject % SIZEOF(ALIGN_TYPE);
	if (odd_bytes > 0)
		sizeofobject += SIZEOF(ALIGN_TYPE) - odd_bytes;

	/* See if space is available in any existing pool */
	if (pool_id < 0 || pool_id >= JPOOL_NUMPOOLS)
		ERREXIT1(cinfo, JERR_BAD_POOL_ID, pool_id);	/* safety check */
	prev_hdr_ptr = NULL;
	hdr_ptr = mem->small_list[pool_id];
	while (hdr_ptr != NULL) {
		if (hdr_ptr->hdr.bytes_left >= sizeofobject)
			break;			/* found pool with enough space */
		prev_hdr_ptr = hdr_ptr;
		hdr_ptr = hdr_ptr->hdr.next;
	}

	/* Time to make a new pool? */
	if (hdr_ptr == NULL) {
		/* min_request is what we need now, slop is what will be leftover */
		min_request = sizeofobject + SIZEOF(small_pool_hdr);
		if (prev_hdr_ptr == NULL)	/* first pool in class? */
			slop = first_pool_slop[pool_id];
		else
			slop = extra_pool_slop[pool_id];
		/* Try to get space, if fail reduce slop and try again */
		for (;;) {
			hdr_ptr = (small_pool_ptr) malloc(min_request + slop);
			if (hdr_ptr != NULL)
				break;
			slop /= 2;
			if (slop < MIN_SLOP)	/* give up when it gets real small */
				out_of_memory(cinfo, 2); /* jpeg_get_small failed */
		}
		/* Success, initialize the new pool header and add to end of list */
		hdr_ptr->hdr.next = NULL;
		hdr_ptr->hdr.bytes_used = 0;
		hdr_ptr->hdr.bytes_left = sizeofobject + slop;
		if (prev_hdr_ptr == NULL)	/* first pool in class? */
			mem->small_list[pool_id] = hdr_ptr;
		else
			prev_hdr_ptr->hdr.next = hdr_ptr;
	}

	/* OK, allocate the object from the current pool */
	data_ptr = (char *) (hdr_ptr + 1); /* point to first data byte in pool */
	data_ptr += hdr_ptr->hdr.bytes_used; /* point to place for object */
	hdr_ptr->hdr.bytes_used += sizeofobject;
	hdr_ptr->hdr.bytes_left -= sizeofobject;

	return (void *) data_ptr;
}


/*
* Allocation of "large" objects.
*
* The external semantics of these are the same as "small" objects,
* except that FAR pointers are used on 80x86.  However the pool
* management heuristics are quite different.  We assume that each
* request is large enough that it may as well be passed directly to
* jpeg_get_large; the pool management just links everything together
* so that we can free it all on demand.
* Note: the major use of "large" objects is in JSAMPARRAY and JBLOCKARRAY
* structures.  The routines that create these structures (see below)
* deliberately bunch rows together to ensure a large request size.
*/

METHODDEF(void *)
alloc_large (j_common_ptr cinfo, int pool_id, size_t sizeofobject)
/* Allocate a "large" object */
{
	my_mem_ptr mem = (my_mem_ptr) cinfo->mem;
	large_pool_ptr hdr_ptr;
	size_t odd_bytes;

	/* Round up the requested size to a multiple of SIZEOF(ALIGN_TYPE) */
	odd_bytes = sizeofobject % SIZEOF(ALIGN_TYPE);
	if (odd_bytes > 0)
		sizeofobject += SIZEOF(ALIGN_TYPE) - odd_bytes;

	/* Always make a new pool */
	if (pool_id < 0 || pool_id >= JPOOL_NUMPOOLS)
		ERREXIT1(cinfo, JERR_BAD_POOL_ID, pool_id);	/* safety check */

	hdr_ptr = (large_pool_ptr) malloc(sizeofobject + SIZEOF(large_pool_hdr));
	if (hdr_ptr == NULL)
		out_of_memory(cinfo, 4);	/* jpeg_get_large failed */

	/* Success, initialize the new pool header and add to list */
	hdr_ptr->hdr.next = mem->large_list[pool_id];
	/* We maintain space counts in each pool header for statistical purposes,
	* even though they are not needed for allocation.
	*/
	hdr_ptr->hdr.bytes_used = sizeofobject;
	hdr_ptr->hdr.bytes_left = 0;
	mem->large_list[pool_id] = hdr_ptr;

	return (void *) (hdr_ptr + 1); /* point to first data byte in pool */
}


/*
* Creation of 2-D sample arrays.
* The pointers are in near heap, the samples themselves in FAR heap.
*
* To minimize allocation overhead and to allow I/O of large contiguous
* blocks, we allocate the sample rows in groups of as many rows as possible
* without exceeding MAX_ALLOC_CHUNK total bytes per allocation request.
* NB: the virtual array control routines, later in this file, know about
* this chunking of rows.  The rowsperchunk value is left in the mem manager
* object so that it can be saved away if this sarray is the workspace for
* a virtual array.
*/

METHODDEF(JSAMPARRAY)
alloc_sarray (j_common_ptr cinfo, int pool_id,
			  JDIMENSION samplesperrow, JDIMENSION numrows)
			  /* Allocate a 2-D sample array */
{
	my_mem_ptr mem = (my_mem_ptr) cinfo->mem;
	JSAMPARRAY result;
	JSAMPROW workspace;
	JDIMENSION i;

	/* [Vita] At most 1 MB per allocation (see alloc_barray). */
	JDIMENSION rowsperchunk, rowsdone, rows;
	long rowbytes = (long) samplesperrow * SIZEOF(JSAMPLE);
	rowsperchunk = rowbytes > 0 ? (JDIMENSION) ((1L << 20) / rowbytes) : numrows;
	if (rowsperchunk < 1) rowsperchunk = 1;
	if (rowsperchunk > numrows) rowsperchunk = numrows;
	mem->last_rowsperchunk = rowsperchunk;

	/* Get space for row pointers (small object) */
	result = (JSAMPARRAY) alloc_small(cinfo, pool_id,
		(size_t) (numrows * SIZEOF(JSAMPROW)));

	/* Get the rows themselves (large objects) */
	rowsdone = 0;
	while (rowsdone < numrows) {
		rows = numrows - rowsdone < rowsperchunk ? numrows - rowsdone : rowsperchunk;
		workspace = (JSAMPROW) alloc_large(cinfo, pool_id,
			(size_t) ((size_t) rows * (size_t) samplesperrow * SIZEOF(JSAMPLE)));
		for (i = 0; i < rows; i++) {
			result[rowsdone + i] = workspace;
			workspace += samplesperrow;
		}
		rowsdone += rows;
	}

	return result;
}


/*
* Creation of 2-D coefficient-block arrays.
* This is essentially the same as the code for sample arrays, above.
*/

METHODDEF(JBLOCKARRAY)
alloc_barray (j_common_ptr cinfo, int pool_id,
			  JDIMENSION blocksperrow, JDIMENSION numrows)
			  /* Allocate a 2-D coefficient-block array */
{
	my_mem_ptr mem = (my_mem_ptr) cinfo->mem;
	JBLOCKARRAY result;
	JBLOCKROW workspace;
	JDIMENSION i;

	/* [Vita] Rows are allocated in chunks of at most 1 MB: a progressive
	   JPEG's coefficient arrays (15-26 MB for HaloDoom's big textures) then
	   fit into a fragmented heap. */
	JDIMENSION rowsperchunk, rowsdone, rows;
	long rowbytes = (long) blocksperrow * SIZEOF(JBLOCK);
	rowsperchunk = rowbytes > 0 ? (JDIMENSION) ((1L << 20) / rowbytes) : numrows;
	if (rowsperchunk < 1) rowsperchunk = 1;
	if (rowsperchunk > numrows) rowsperchunk = numrows;
	mem->last_rowsperchunk = rowsperchunk;

	/* Get space for row pointers (small object) */
	result = (JBLOCKARRAY) alloc_small(cinfo, pool_id,
		(size_t) (numrows * SIZEOF(JBLOCKROW)));

	/* Get the rows themselves (large objects) */
	rowsdone = 0;
	while (rowsdone < numrows) {
		rows = numrows - rowsdone < rowsperchunk ? numrows - rowsdone : rowsperchunk;
		workspace = (JBLOCKROW) alloc_large(cinfo, pool_id,
			(size_t) ((size_t) rows * (size_t) blocksperrow * SIZEOF(JBLOCK)));
		for (i = 0; i < rows; i++) {
			result[rowsdone + i] = workspace;
			workspace += blocksperrow;
		}
		rowsdone += rows;
	}

	return result;
}


/*
* About virtual array management:
*
* The above "normal" array routines are only used to allocate strip buffers
* (as wide as the image, but just a few rows high).  Full-image-sized buffers
* are handled as "virtual" arrays.  The array is still accessed a strip at a
* time, but the memory manager must save the whole array for repeated
* accesses.  The intended implementation is that there is a strip buffer in
* memory (as high as is possible given the desired memory limit), plus a
* backing file that holds the rest of the array.
*
* The request_virt_array routines are told the total size of the image and
* the maximum number of rows that will be accessed at once.  The in-memory
* buffer must be at least as large as the maxaccess value.
*
* The request routines create control blocks but not the in-memory buffers.
* That is postponed until realize_virt_arrays is called.  At that time the
* total amount of space needed is known (approximately, anyway), so free
* memory can be divided up fairly.
*
* The access_virt_array routines are responsible for making a specific strip
* area accessible (after reading or writing the backing file, if necessary).
* Note that the access routines are told whether the caller intends to modify
* the accessed strip; during a read-only pass this saves having to rewrite
* data to disk.  The access routines are also responsible for pre-zeroing
* any newly accessed rows, if pre-zeroing was requested.
*
* In current usage, the access requests are usually for nonoverlapping
* strips; that is, successive access start_row numbers differ by exactly
* num_rows = maxaccess.  This means we can get good performance with simple
* buffer dump/reload logic, by making the in-memory buffer be a multiple
* of the access height; then there will never be accesses across bufferload
* boundaries.  The code will still work with overlapping access requests,
* but it doesn't handle bufferload overlaps very efficiently.
*/


METHODDEF(jvirt_barray_ptr)
request_virt_barray (j_common_ptr cinfo, int pool_id, boolean pre_zero,
					 JDIMENSION blocksperrow, JDIMENSION numrows,
					 JDIMENSION maxaccess)
					 /* Request a virtual 2-D coefficient-block array */
{
	my_mem_ptr mem = (my_mem_ptr) cinfo->mem;
	jvirt_barray_ptr result;

	/* Only IMAGE-lifetime virtual arrays are currently supported */
	if (pool_id != JPOOL_IMAGE)
		ERREXIT1(cinfo, JERR_BAD_POOL_ID, pool_id);	/* safety check */

	/* get control block */
	result = (jvirt_barray_ptr) alloc_small(cinfo, pool_id,
		SIZEOF(struct jvirt_barray_control));

	result->mem_buffer = NULL;	/* marks array not yet realized */
	result->rows_in_array = numrows;
	result->blocksperrow = blocksperrow;
	result->maxaccess = maxaccess;
	result->pre_zero = pre_zero;
	result->next = mem->virt_barray_list; /* add to list of virtual arrays */
	mem->virt_barray_list = result;

	return result;
}


METHODDEF(void)
realize_virt_arrays (j_common_ptr cinfo)
/* Allocate the in-memory buffers for any unrealized virtual arrays */
{
	my_mem_ptr mem = (my_mem_ptr) cinfo->mem;
	long space_per_minheight;
	long minheights;
	jvirt_barray_ptr bptr;

	/* Compute the minimum space needed (maxaccess rows in each buffer)
	* and the maximum space needed (full image height in each buffer).
	* These may be of use to the system-dependent jpeg_mem_available routine.
	*/
	space_per_minheight = 0;
	for (bptr = mem->virt_barray_list; bptr != NULL; bptr = bptr->next) {
		if (bptr->mem_buffer == NULL) { /* if not realized yet */
			space_per_minheight += (long) bptr->maxaccess *
				(long) bptr->blocksperrow * SIZEOF(JBLOCK);
		}
	}

	if (space_per_minheight <= 0)
		return;			/* no unrealized arrays, no work */

	/* Allocate the in-memory buffers and initialize backing store as needed. */

	for (bptr = mem->virt_barray_list; bptr != NULL; bptr = bptr->next) {
		if (bptr->mem_buffer == NULL) { /* if not realized yet */
			minheights = ((long) bptr->rows_in_array - 1L) / bptr->maxaccess + 1L;
			bptr->rows_in_mem = bptr->rows_in_array;
			bptr->mem_buffer = alloc_barray(cinfo, JPOOL_IMAGE,
				bptr->blocksperrow, bptr->rows_in_mem);
			bptr->rowsperchunk = mem->last_rowsperchunk;
			bptr->cur_start_row = 0;
			bptr->first_undef_row = 0;
			bptr->dirty = FALSE;
		}
	}
}



METHODDEF(JBLOCKARRAY)
access_virt_barray (j_common_ptr cinfo, jvirt_barray_ptr ptr,
					JDIMENSION start_row, JDIMENSION num_rows,
					boolean writable)
					/* Access the part of a virtual block array starting at start_row */
					/* and extending for num_rows rows.  writable is true if  */
					/* caller intends to modify the accessed area. */
{
	JDIMENSION end_row = start_row + num_rows;
	JDIMENSION undef_row;

	/* debugging check */
	if (end_row > ptr->rows_in_array || num_rows > ptr->maxaccess ||
		ptr->mem_buffer == NULL)
		ERREXIT(cinfo, JERR_BAD_VIRTUAL_ACCESS);

	/* Make the desired part of the virtual array accessible */
	if (start_row < ptr->cur_start_row || end_row > ptr->cur_start_row+ptr->rows_in_mem)
		ERREXIT(cinfo, JERR_VIRTUAL_BUG);

	/* Ensure the accessed part of the array is defined; prezero if needed.
	* To improve locality of access, we only prezero the part of the array
	* that the caller is about to access, not the entire in-memory array.
	*/
	if (ptr->first_undef_row < end_row) {
		if (ptr->first_undef_row < start_row) {
			if (writable)		/* writer skipped over a section of array */
				ERREXIT(cinfo, JERR_BAD_VIRTUAL_ACCESS);
			undef_row = start_row;	/* but reader is allowed to read ahead */
		} else {
			undef_row = ptr->first_undef_row;
		}
		if (writable)
			ptr->first_undef_row = end_row;
		if (ptr->pre_zero) {
			size_t bytesperrow = (size_t) ptr->blocksperrow * SIZEOF(JBLOCK);
			undef_row -= ptr->cur_start_row; /* make indexes relative to buffer */
			end_row -= ptr->cur_start_row;
			while (undef_row < end_row) {
				MEMZERO((void *) ptr->mem_buffer[undef_row], bytesperrow);
				undef_row++;
			}
		} else {
			if (! writable)		/* reader looking at undefined data */
				ERREXIT(cinfo, JERR_BAD_VIRTUAL_ACCESS);
		}
	}
	/* Flag the buffer dirty if caller will write in it */
	if (writable)
		ptr->dirty = TRUE;
	/* Return address of proper part of the buffer */
	return ptr->mem_buffer + (start_row - ptr->cur_start_row);
}


/*
* Release all objects belonging to a specified pool.
*/

METHODDEF(void)
free_pool (j_common_ptr cinfo, int pool_id)
{
	my_mem_ptr mem = (my_mem_ptr) cinfo->mem;
	small_pool_ptr shdr_ptr;
	large_pool_ptr lhdr_ptr;

	if (pool_id < 0 || pool_id >= JPOOL_NUMPOOLS)
		ERREXIT1(cinfo, JERR_BAD_POOL_ID, pool_id);	/* safety check */

	/* Release large objects */
	lhdr_ptr = mem->large_list[pool_id];
	mem->large_list[pool_id] = NULL;

	while (lhdr_ptr != NULL) {
		large_pool_ptr next_lhdr_ptr = lhdr_ptr->hdr.next;
		free(lhdr_ptr);
		lhdr_ptr = next_lhdr_ptr;
	}

	/* Release small objects */
	shdr_ptr = mem->small_list[pool_id];
	mem->small_list[pool_id] = NULL;

	while (shdr_ptr != NULL) {
		small_pool_ptr next_shdr_ptr = shdr_ptr->hdr.next;
		free(shdr_ptr);
		shdr_ptr = next_shdr_ptr;
	}
}


/*
* Close up shop entirely.
* Note that this cannot be called unless cinfo->mem is non-NULL.
*/

METHODDEF(void)
self_destruct (j_common_ptr cinfo)
{
	int pool;

	/* Close all backing store, release all memory.
	* Releasing pools in reverse order might help avoid fragmentation
	* with some (brain-damaged) malloc libraries.
	*/
	for (pool = JPOOL_NUMPOOLS-1; pool >= JPOOL_PERMANENT; pool--) {
		free_pool(cinfo, pool);
	}

	/* Release the memory manager control block too. */
	free(cinfo->mem);
	cinfo->mem = NULL;		/* ensures I will be called only once */
}


/*
* Memory manager initialization.
* When this is called, only the error manager pointer is valid in cinfo!
*/

GLOBAL(void)
jinit_memory_mgr (j_common_ptr cinfo)
{
	my_mem_ptr mem;
	int pool;

	cinfo->mem = NULL;		/* for safety if init fails */

	/* Check for configuration errors.
	* SIZEOF(ALIGN_TYPE) should be a power of 2; otherwise, it probably
	* doesn't reflect any real hardware alignment requirement.
	* The test is a little tricky: for X>0, X and X-1 have no one-bits
	* in common if and only if X is a power of 2, ie has only one one-bit.
	* Some compilers may give an "unreachable code" warning here; ignore it.
	*/
	if ((SIZEOF(ALIGN_TYPE) & (SIZEOF(ALIGN_TYPE)-1)) != 0)
		ERREXIT(cinfo, JERR_BAD_ALIGN_TYPE);

	/* Attempt to allocate memory manager's control block */
	mem = (my_mem_ptr) malloc(SIZEOF(my_memory_mgr));

	if (mem == NULL) {
		ERREXIT1(cinfo, JERR_OUT_OF_MEMORY, 0);
	}

	/* OK, fill in the method pointers */
	mem->pub.alloc_small = alloc_small;
	mem->pub.alloc_large = alloc_large;
	mem->pub.alloc_sarray = alloc_sarray;
	mem->pub.alloc_barray = alloc_barray;
	mem->pub.request_virt_barray = request_virt_barray;
	mem->pub.realize_virt_arrays = realize_virt_arrays;
	mem->pub.access_virt_barray = access_virt_barray;
	mem->pub.free_pool = free_pool;
	mem->pub.self_destruct = self_destruct;

	/* Initialize working state */
	for (pool = JPOOL_NUMPOOLS-1; pool >= JPOOL_PERMANENT; pool--) {
		mem->small_list[pool] = NULL;
		mem->large_list[pool] = NULL;
	}
	mem->virt_barray_list = NULL;

	/* Declare ourselves open for business */
	cinfo->mem = & mem->pub;
}
