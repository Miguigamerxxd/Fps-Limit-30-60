# Zandronum Vita - FPS selector experiment (30/60)

This is the original Zandronum Vita source tree with an experimental FPS-limit selector.

## Changes
- Launcher selector: LEFT = 30 FPS, RIGHT = 60 FPS.
- The selection is stored in `ux0:data/zandronum/launcher.cfg`.
- The launcher passes the selected `vid_maxfps` value to the engine at startup.
- Vita frame pacing is implemented at the framebuffer/OpenGL present points using Vita kernel time/delay APIs.

## Important
This source package is **not a compiled VPK**. It has not been compiled or tested on a PS Vita.
The current execution environment did not have VitaSDK tools installed and could not reach GitHub to install them. Treat this as an experimental test source, not a verified release.

## Build
Install VitaSDK and the Vita-targeted libraries required by this project's CMake configuration. Then, from this directory:

```sh
export VITASDK=/usr/local/vitasdk
export PATH="$VITASDK/bin:$PATH"
cmake -S . -B build-vita \
  -DCMAKE_TOOLCHAIN_FILE="$VITASDK/share/vita.toolchain.cmake" \
  -DVITA=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-vita --target zandronum.vpk
```

The project defines the `zandronum.vpk` target in `src/CMakeLists.txt`; dependency availability may require installing additional VitaSDK packages via `vdpm`.

## Test notes
- Confirm the launcher displays `FPS LIMIT: 30` by default.
- Press RIGHT and confirm it changes to 60; press LEFT to return to 30.
- Launch the same map/scene at both settings and compare frame pacing.
- 60 FPS is a cap target, not a guarantee that every scene will run at 60 FPS on Vita.
